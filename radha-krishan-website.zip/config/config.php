<?php $BASE_URL = "http://localhost/radha-krishan-website/"; ?>

