<section class="FeaturedProduct_wrapper">
        <div class="featured-product">
            <div class="container">
                <h3 class="section_heading m-bd text-center mb-41  text-green" id="FeaturedProductWrapperHeading"></h3>
                <div class="swiper featuredCardSwiper">
                    <div class="swiper-wrapper pb-90" id="customProductCardSlider">
                        <!-- <div class="swiper-slide">
                            <div class="product-card overflow-hidden rounded-4 bg-white ">
                                <div class="product_image position-relative">
                                    <div class="swiper productImageSwiper">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <img src="./assets/img/earingProduct.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/earingProduct.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/earingProduct.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                        </div>
                                        <div class="swiper-button-next small_swiper_btn"></div>
                                        <div class="swiper-button-prev small_swiper_btn"></div>
                                    </div>
                                    <button
                                        class="wishlist_btn end-15 top-15 position-absolute  bg-white rounded-circle">
                                        <img src="./assets/img/heart.svg" width="" height="" alt="wishlist-icon">
                                    </button>
                                    <div class="bg-orange rounded-2 px-2 py-1 position-absolute z-2  top-15 start-15">
                                        <span class="text-white m-sbd product_label_text">Best Seller</span>
                                    </div>
                                </div>
                                <a href="./ProductDetail.html" class="d-flex flex-column p-14">
                                    <h2 class="product_title m-sbd text-black text-start">Silver Earring</h2>
                                    <p class="product_text m-reg text-start text-grey ">It is a long established fact
                                        that a reader will be distracted by the readable content of a page when looking
                                        at its layout. </p>
                                    <p class="product_discount_text mb-0">
                                        <span class="text-grey m-reg "><b class="m-bd ">20%</b> Discount on making
                                            charges</span>
                                    </p>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="product-card overflow-hidden rounded-4 bg-white ">
                                <div class="product_image position-relative">
                                    <div class="swiper productImageSwiper">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <img src="./assets/img/kangan.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/kangan.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/kangan.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                        </div>
                                        <div class="swiper-button-next small_swiper_btn"></div>
                                        <div class="swiper-button-prev small_swiper_btn"></div>
                                    </div>
                                    <button
                                        class="wishlist_btn end-15 top-15 position-absolute  bg-white rounded-circle">
                                        <img src="./assets/img/heart.svg" width="" height="" alt="wishlist-icon">
                                    </button>
                                    <div class="bg-green rounded-2 px-2 py-1 position-absolute z-2  top-15 start-15">
                                        <span class="text-white m-sbd product_label_text">New</span>
                                    </div>
                                </div>
                                <a href="./ProductDetail.html" class="d-flex flex-column p-14">
                                    <h2 class="product_title m-sbd text-black text-start">Silver Earring</h2>
                                    <p class="product_text m-reg text-start text-grey ">It is a long established fact
                                        that a reader will be distracted by the readable content of a page when looking
                                        at its layout. </p>
                                    <p class="product_discount_text mb-0">
                                        <span class="text-grey m-reg "><b class="m-bd ">20%</b> Discount on making
                                            charges</span>
                                    </p>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="product-card overflow-hidden rounded-4 bg-white ">
                                <div class="product_image position-relative">
                                    <div class="swiper productImageSwiper">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <img src="./assets/img/earing2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/earing2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/earing2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                        </div>
                                        <div class="swiper-button-next small_swiper_btn"></div>
                                        <div class="swiper-button-prev small_swiper_btn"></div>
                                    </div>
                                    <button
                                        class="wishlist_btn end-15 top-15 position-absolute  bg-white rounded-circle">
                                        <img src="./assets/img/heart.svg" width="" height="" alt="wishlist-icon">
                                    </button>
                                </div>
                                <a href="./ProductDetail.html" class="d-flex flex-column p-14">
                                    <h2 class="product_title m-sbd text-black text-start">Silver Earring</h2>
                                    <p class="product_text m-reg text-start text-grey ">It is a long established fact
                                        that a reader will be distracted by the readable content of a page when looking
                                        at its layout. </p>
                                    <p class="product_discount_text  mb-0">
                                        <span class="text-grey m-reg "><b class="m-bd ">20%</b> Discount on making
                                            charges</span>
                                    </p>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="product-card overflow-hidden rounded-4 bg-white ">
                                <div class="product_image position-relative">
                                    <div class="swiper productImageSwiper">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <img src="./assets/img/star.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/star.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/star.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                        </div>
                                        <div class="swiper-button-next small_swiper_btn"></div>
                                        <div class="swiper-button-prev small_swiper_btn"></div>
                                    </div>
                                    <button
                                        class="wishlist_btn end-15 top-15 position-absolute  bg-white rounded-circle">
                                        <img src="./assets/img/heart.svg" width="" height="" alt="wishlist-icon">
                                    </button>
                                </div>
                                <a href="./ProductDetail.html" class="d-flex flex-column p-14">
                                    <h2 class="product_title m-sbd text-black text-start">Silver Earring</h2>
                                    <p class="product_text m-reg text-start text-grey ">It is a long established fact
                                        that a reader will be distracted by the readable content of a page when looking
                                        at its layout. </p>
                                    <p class="product_discount_text mb-0">
                                        <span class="text-grey m-reg "><b class="m-bd ">20%</b> Discount on making
                                            charges</span>
                                    </p>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="product-card overflow-hidden rounded-4 bg-white ">
                                <div class="product_image position-relative">
                                    <div class="swiper productImageSwiper">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <img src="./assets/img/mangalsutra2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/mangalsutra2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/mangalsutra2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                        </div>
                                        <div class="swiper-button-next small_swiper_btn"></div>
                                        <div class="swiper-button-prev small_swiper_btn"></div>
                                    </div>
                                    <button
                                        class="wishlist_btn end-15 top-15 position-absolute  bg-white rounded-circle">
                                        <img src="./assets/img/heart.svg" width="" height="" alt="wishlist-icon">
                                    </button>
                                </div>
                                <a href="./ProductDetail.html" class="d-flex flex-column p-14">
                                    <h2 class="product_title m-sbd text-black text-start">Silver Earring</h2>
                                    <p class="product_text m-reg text-start text-grey ">It is a long established fact
                                        that a reader will be distracted by the readable content of a page when looking
                                        at its layout. </p>
                                    <p class="product_discount_text mb-0">
                                        <span class="text-grey m-reg "><b class="m-bd ">20%</b> Discount on making
                                            charges</span>
                                    </p>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="product-card overflow-hidden rounded-4 bg-white ">
                                <div class="product_image position-relative">
                                    <div class="swiper productImageSwiper">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <img src="./assets/img/mangalsutra2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/mangalsutra2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/mangalsutra2.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                        </div>
                                        <div class="swiper-button-next small_swiper_btn"></div>
                                        <div class="swiper-button-prev small_swiper_btn"></div>
                                    </div>
                                    <button
                                        class="wishlist_btn end-15 top-15 position-absolute  bg-white rounded-circle">
                                        <img src="./assets/img/heart.svg" width="" height="" alt="wishlist-icon">
                                    </button>
                                </div>
                                <a href="./ProductDetail.html" class="d-flex flex-column p-14">
                                    <h2 class="product_title m-sbd text-black text-start">Silver Earring</h2>
                                    <p class="product_text m-reg text-start text-grey ">It is a long established fact
                                        that a reader will be distracted by the readable content of a page when looking
                                        at its layout. </p>
                                    <p class="product_discount_text mb-0">
                                        <span class="text-grey m-reg "><b class="m-bd ">20%</b> Discount on making
                                            charges</span>
                                    </p>
                                </a>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="product-card overflow-hidden rounded-4 bg-white ">
                                <div class="product_image position-relative">
                                    <div class="swiper productImageSwiper">
                                        <div class="swiper-wrapper">
                                            <div class="swiper-slide">
                                                <img src="./assets/img/star.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/star.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                            <div class="swiper-slide">
                                                <img src="./assets/img/star.webp" alt="product-image" width=""
                                                    height="">
                                            </div>
                                        </div>
                                        <div class="swiper-button-next small_swiper_btn"></div>
                                        <div class="swiper-button-prev small_swiper_btn"></div>
                                    </div>
                                    <button
                                        class="wishlist_btn end-15 top-15 position-absolute  bg-white rounded-circle">
                                        <img src="./assets/img/heart.svg" width="" height="" alt="wishlist-icon">
                                    </button>
                                </div>
                                <a href="./ProductDetail.html" class="d-flex flex-column p-14">
                                    <h2 class="product_title m-sbd text-black text-start">Silver Earring</h2>
                                    <p class="product_text m-reg text-start text-grey ">It is a long established fact
                                        that a reader will be distracted by the readable content of a page when looking
                                        at its layout. </p>
                                    <p class="product_discount_text mb-0">
                                        <span class="text-grey m-reg "><b class="m-bd ">20%</b> Discount on making
                                            charges</span>
                                    </p>
                                </a>
                            </div>
                        </div> -->

                    </div>
                    <div class="swiper-pagination"></div>
                </div>

            </div>
        </div>

    </section>