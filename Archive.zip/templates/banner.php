<section class="banner_wrapper">
        <div class="swiper mySwiper homeBanner">
            <div class="swiper-wrapper" id="custom-swiper-slide">
            </div>
            <!-- <div class="swiper-button-next swiper-button "></div>
            <div class="swiper-button-prev swiper-button "></div> -->
            <div class="swiper-pagination"></div>
        </div>
    </section>