<section class="offer_wrapper">
        <div class="my-md-5 py-md-5 my-3 py-3">
            <div class="container">
                <h3 class="section_heading m-bd text-center  text-green">Offers</h3>
                <div class="swiper offerSwiper">
                    <div class="swiper-wrapper py-offerSwiper" id="offersSliderWrapper">
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </section>