<script>
const APP__NAME = "Radha Kishan Jewellers";
const API_BASE_URL = "https://radha-krishna-admin.myclientdemo.us/api";
const TOKEN_PREFIX = "RKJ-";
const BASE_URL = '<?= $BASE_URL; ?>';
const PICKUP_POSTCODE = '700002';
const BUILD_VERSION = "0.0000334";
const RZP_KEY = "rzp_test_C2x6DSQJvk16KA";
const emitter = new EventEmitter();
</script>
